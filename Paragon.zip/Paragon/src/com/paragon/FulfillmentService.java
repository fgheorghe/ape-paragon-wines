package com.paragon;

import com.paragon.orders.Order;

public interface FulfillmentService {
    void placeOrder(Order order);
}
